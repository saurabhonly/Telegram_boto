import asyncio
import json
import os
import re
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    CallbackQueryHandler,
)

BOT_TOKEN       = os.environ["BOT_TOKEN"]
YOUTUBE_API_KEY = os.environ["YOUTUBE_API_KEY"]
TMDB_API_KEY    = os.environ["TMDB_API_KEY"]

VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".ogv", ".mov", ".webm"}
MIN_MOVIE_MB     = 50
TMDB_IMG_BASE    = "https://image.tmdb.org/t/p/w500"

SKIP_WORDS = {
    "clip", "trailer", "teaser", "scene", "short", "excerpt",
    "preview", "promo", "song", "music", "ost", "dance",
    "interview", "making", "behind the scenes", "reaction",
    "review", "highlight", "reel", "montage", "cut",
}

QUALITY_LABELS = {
    "2160": "4K (2160p) 🔥",
    "1080": "1080p HD ⭐",
    "720":  "720p HD",
    "480":  "480p",
    "360":  "360p",
    "320":  "320p",
    "240":  "240p SD",
    "other": "Standard",
}

# Preferred format order for deduplication
FORMAT_PREF = [".mp4", ".mkv", ".webm", ".avi", ".ogv", ".mov"]
SOURCE_LABELS = {
    "archive":   "🏛️ Archive.org",
    "wikimedia": "🌐 Wikimedia",
    "search":    "🔍 Archive.org Search",
}


# ══════════════════════════════════════════════
# RELEVANCE SCORING
# ══════════════════════════════════════════════

def title_score(result_title: str, query: str) -> float:
    r     = result_title.lower().strip()
    t     = query.lower().strip()
    seq   = SequenceMatcher(None, r, t).ratio()
    words = [w for w in re.split(r"\W+", t) if len(w) > 2]
    hits  = sum(1 for w in words if w in r) if words else 0
    word  = hits / len(words) if words else 0
    return round(0.55 * seq + 0.45 * word, 4)


# ══════════════════════════════════════════════
# SOURCE 1 — Internet Archive
# ══════════════════════════════════════════════

def search_archive(query: str) -> list[dict]:
    return _archive_api(f'"{query}"') or _archive_api(query)


def _is_short_clip(title: str, duration: float) -> bool:
    tl = title.lower()
    if any(word in tl for word in SKIP_WORDS):
        return True
    if duration and 0 < duration < 1800:
        return True
    return False


def _archive_api(term: str) -> list[dict]:
    q   = requests.utils.quote(term)
    url = (
        "https://archive.org/advancedsearch.php"
        f"?q={q}+AND+mediatype:(movies)"
        "&fl[]=identifier,title,duration&output=json&rows=15&sort[]=downloads+desc"
    )
    try:
        res = requests.get(url, timeout=12).json()
    except Exception:
        return []
    out = []
    for doc in res.get("response", {}).get("docs", []):
        t   = doc.get("title", "").strip()
        iid = doc.get("identifier", "").strip()
        dur = float(doc.get("duration") or 0)
        if not t or not iid:
            continue
        if _is_short_clip(t, dur):
            continue
        out.append({
            "title":       t,
            "source":      "archive",
            "identifier":  iid,
            "thumb":       f"https://archive.org/services/img/{iid}",
            "watch_url":   f"https://archive.org/details/{iid}",
            "score":       0.0,
            "is_fallback": False,
        })
    return out


# ══════════════════════════════════════════════
# SOURCE 2 — Wikimedia Commons
# ══════════════════════════════════════════════

def search_wikimedia(query: str) -> list[dict]:
    API        = "https://commons.wikimedia.org/w/api.php"
    VIDEO_EXTS = {".ogv", ".webm", ".mp4", ".ogg"}
    try:
        s = requests.get(API, params={
            "action": "query", "list": "search",
            "srsearch": f"{query} film", "srnamespace": 6,
            "srlimit": 10, "srprop": "title", "format": "json",
        }, timeout=12).json()
        items = s.get("query", {}).get("search", [])
    except Exception:
        return []

    file_titles = [
        it["title"] for it in items
        if os.path.splitext(it.get("title", ""))[1].lower() in VIDEO_EXTS
    ]
    if not file_titles:
        return []

    try:
        info  = requests.get(API, params={
            "action": "query", "titles": "|".join(file_titles[:5]),
            "prop": "imageinfo", "iiprop": "url|thumburl|size",
            "iiurlwidth": 500, "format": "json",
        }, timeout=12).json()
        pages = info.get("query", {}).get("pages", {})
    except Exception:
        return []

    out = []
    for page in pages.values():
        fname  = page.get("title", "")
        iinfo  = (page.get("imageinfo") or [{}])[0]
        direct = iinfo.get("url", "")
        thumb  = iinfo.get("thumburl", "") or direct
        if not direct:
            continue
        display = re.sub(r"^File:", "", fname)
        display = os.path.splitext(display)[0].replace("_", " ").strip()
        out.append({
            "title":      display,
            "source":     "wikimedia",
            "identifier": fname,
            "thumb":      thumb,
            "watch_url":  f"https://commons.wikimedia.org/wiki/{fname.replace(' ', '_')}",
            "direct_url": direct,
            "score":      0.0,
            "is_fallback": False,
        })
    return out


# ══════════════════════════════════════════════
# FALLBACK — Archive.org search page
# ══════════════════════════════════════════════

def make_search_fallback(query: str, poster_url: str | None) -> dict:
    search_url = (
        "https://archive.org/search"
        f"?query={requests.utils.quote(query)}"
        "&and[]=mediatype%3A%22movies%22"
    )
    return {
        "title":      query,
        "source":     "search",
        "identifier": None,
        "thumb":      poster_url or "",
        "watch_url":  search_url,
        "score":      1.0,
        "is_fallback": True,
        "search_url": search_url,
    }


# ══════════════════════════════════════════════
# TMDB — only for metadata/poster
# ══════════════════════════════════════════════

def tmdb_enrich(query: str) -> dict:
    try:
        data = requests.get(
            "https://api.themoviedb.org/3/search/multi",
            params={"api_key": TMDB_API_KEY, "query": query, "page": 1},
            timeout=10,
        ).json()
    except Exception:
        return {}
    for item in data.get("results", []):
        if item.get("media_type") not in ("movie", "tv"):
            continue
        title  = item.get("title") or item.get("name") or ""
        year   = (item.get("release_date") or item.get("first_air_date") or "")[:4]
        poster = item.get("poster_path")
        if not title:
            continue
        return {
            "title":      title,
            "year":       year,
            "poster_url": (TMDB_IMG_BASE + poster) if poster else None,
            "language":   item.get("original_language", "").upper(),
            "overview":   (item.get("overview") or "")[:200],
        }
    return {}


# ══════════════════════════════════════════════
# MULTI-SOURCE SEARCH
# ══════════════════════════════════════════════

def run_all_sources(query: str, poster_url: str | None = None) -> list[dict]:
    all_results: list[dict] = []
    with ThreadPoolExecutor(max_workers=2) as ex:
        futures = {
            ex.submit(search_archive,   query): "archive",
            ex.submit(search_wikimedia, query): "wikimedia",
        }
        for future in as_completed(futures):
            try:
                all_results.extend(future.result())
            except Exception:
                pass

    for r in all_results:
        r["score"] = title_score(r["title"], query)

    all_results.sort(
        key=lambda x: (-x["score"], {"archive": 0, "wikimedia": 1}.get(x["source"], 9))
    )

    seen: set[str] = set()
    ranked: list[dict] = []
    for r in all_results:
        if r["watch_url"] not in seen:
            seen.add(r["watch_url"])
            ranked.append(r)

    top = ranked[:3]
    if not top:
        top = [make_search_fallback(query, poster_url)]
    elif len(top) < 3:
        top.append(make_search_fallback(query, poster_url))

    return top


# ══════════════════════════════════════════════
# ARCHIVE.ORG file list for download
# ══════════════════════════════════════════════

def get_archive_files(identifier: str) -> list[dict]:
    try:
        meta = requests.get(
            f"https://archive.org/metadata/{identifier}", timeout=12
        ).json()
    except Exception:
        return []

    # Collect all video files
    candidates: list[dict] = []
    for f in meta.get("files", []):
        name: str = f.get("name", "")
        ext       = os.path.splitext(name)[1].lower()
        if ext not in VIDEO_EXTENSIONS:
            continue
        size_mb = round(int(f.get("size", 0) or 0) / (1024 * 1024), 1)
        quality = _detect_quality(name, f)
        dl_url  = (
            f"https://archive.org/download/{identifier}/"
            + requests.utils.quote(name)
        )
        candidates.append({
            "name":    name,
            "quality": quality,
            "size_mb": size_mb,
            "url":     dl_url,
            "ext":     ext,
        })

    # Deduplicate: one best file per quality (prefer .mp4 > .mkv > .webm > others)
    best: dict[str, dict] = {}
    for c in candidates:
        q = c["quality"]
        if q not in best:
            best[q] = c
        else:
            curr_pref = FORMAT_PREF.index(best[q]["ext"]) if best[q]["ext"] in FORMAT_PREF else 99
            new_pref  = FORMAT_PREF.index(c["ext"])       if c["ext"]       in FORMAT_PREF else 99
            if new_pref < curr_pref:
                best[q] = c

    order = ["2160", "1080", "720", "480", "360", "320", "240", "other"]
    files = sorted(
        best.values(),
        key=lambda x: order.index(x["quality"]) if x["quality"] in order else len(order),
    )
    return list(files)


def _detect_quality(filename: str, meta: dict) -> str:
    """Detect quality using height metadata (most accurate), then filename."""
    # 1. height field from Archive.org metadata
    height = int(meta.get("height", 0) or 0)
    if height:
        if height >= 1440: return "2160"
        if height >= 900:  return "1080"
        if height >= 600:  return "720"
        if height >= 420:  return "480"
        if height >= 340:  return "360"
        if height >= 280:  return "320"
        return "240"

    # 2. Filename keywords
    name_lower = filename.lower()
    for key in ["2160", "4k", "1080", "720", "480", "360", "320", "240"]:
        if key in name_lower:
            return "2160" if key == "4k" else key

    return "other"


# ══════════════════════════════════════════════
# SEND RESULT CARD
# ══════════════════════════════════════════════

async def send_result_card(chat_id: int, bot, idx: int, result: dict, tmdb: dict):
    src_lbl   = SOURCE_LABELS.get(result["source"], result["source"])
    score_pct = int(result["score"] * 100)
    title     = result["title"]
    is_fb     = result.get("is_fallback", False)

    photo    = (tmdb.get("poster_url") if idx == 0 and tmdb.get("poster_url")
                else result.get("thumb", ""))
    year_tag = f" ({tmdb['year']})" if idx == 0 and tmdb.get("year") else ""
    overview = f"\n_{tmdb['overview']}_" if idx == 0 and tmdb.get("overview") else ""

    if is_fb:
        caption = (
            f"🔍 *{title}* — Archive.org Search\n\n"
            "Directly indexed nahi mili, lekin\n"
            "Archive.org pe search karke dekho 👇"
            + overview
        )
    else:
        caption = (
            f"{src_lbl}  |  🎯 {score_pct}% match\n"
            f"🎬 *{title}*{year_tag}" + overview
        )

    source = result["source"]
    if source == "archive":
        buttons = [[
            InlineKeyboardButton("📺 Watch on Archive.org", url=result["watch_url"]),
            InlineKeyboardButton("📥 Download",             callback_data=f"download_{idx}"),
        ]]
    elif source == "wikimedia":
        buttons = [[
            InlineKeyboardButton("📺 Watch",   url=result["watch_url"]),
            InlineKeyboardButton("📥 Download", callback_data=f"download_{idx}"),
        ]]
    else:
        buttons = [[
            InlineKeyboardButton("🔍 Browse on Archive.org", url=result["watch_url"]),
            InlineKeyboardButton("📥 Download",              callback_data=f"download_{idx}"),
        ]]

    markup = InlineKeyboardMarkup(buttons)
    try:
        if photo:
            await bot.send_photo(
                chat_id=chat_id, photo=photo,
                caption=caption, parse_mode="Markdown",
                reply_markup=markup,
            )
            return
    except Exception:
        pass
    await bot.send_message(
        chat_id=chat_id, text=caption,
        parse_mode="Markdown", reply_markup=markup,
    )


# ══════════════════════════════════════════════
# HANDLERS
# ══════════════════════════════════════════════

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "🎬 *Movie & Web Series Bot*\n\n"
        "Kisi bhi movie ka naam type karo!\n\n"
        "📺 *Watch* → Archive.org pe seedha dekho\n"
        "📥 *Download* → Quality chunke download karo\n\n"
        "Dono bilkul *free* hain! Naam bhejo 👇",
        parse_mode="Markdown",
    )


async def search(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.message.text.strip()
    if not query:
        return

    msg = await update.message.reply_text(
        f"🔍 *\"{query}\"* search ho raha hai...",
        parse_mode="Markdown",
    )

    with ThreadPoolExecutor(max_workers=2) as ex:
        tmdb_f    = ex.submit(tmdb_enrich, query)
        sources_f = ex.submit(run_all_sources, query, None)
        tmdb      = tmdb_f.result()
        results   = sources_f.result()

    for r in results:
        if r.get("is_fallback") and not r.get("thumb"):
            r["thumb"] = tmdb.get("poster_url", "")

    context.user_data["results"] = results
    context.user_data["tmdb"]    = tmdb

    await msg.delete()

    header = (
        f"🎬 *{tmdb.get('title', query)}*"
        + (f" ({tmdb['year']})" if tmdb.get("year") else "")
        + (f"  🌐 {tmdb['language']}" if tmdb.get("language") else "")
        + "\n\n📺 Watch: *Free*  |  📥 Download: *Free*\n"
        + "─" * 20
    )
    await update.message.reply_text(header, parse_mode="Markdown")

    for i, result in enumerate(results):
        await send_result_card(
            chat_id=update.effective_chat.id,
            bot=context.bot,
            idx=i,
            result=result,
            tmdb=tmdb,
        )


# ── Download — direct, no lock ────────────────

async def handle_download(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()

    idx     = int(q.data.split("_")[1])
    results = context.user_data.get("results", [])
    tmdb    = context.user_data.get("tmdb", {})

    if idx >= len(results):
        await q.message.reply_text("⚠️ Session expire ho gayi. Dobara search karo.")
        return

    result = results[idx]
    title  = tmdb.get("title") or result["title"]
    source = result["source"]

    if source == "archive" and result.get("identifier"):
        wait  = await q.message.reply_text("⏳ Download files dhundh raha hun...")
        files = get_archive_files(result["identifier"])
        await wait.delete()

        if not files:
            await q.message.reply_text(
                f"⚠️ Direct files nahi mili.\n"
                f"🌐 Archive.org pe dekho:\n{result['watch_url']}"
            )
            return

        btns: list[list[InlineKeyboardButton]] = []
        for f in files:
            label = QUALITY_LABELS.get(f["quality"], f"Quality {f['quality']}")
            size  = f" ({f['size_mb']} MB)" if f.get("size_mb", 0) > 0 else ""
            btns.append([InlineKeyboardButton(f"📥 {label}{size}", url=f["url"])])

        btns.append([InlineKeyboardButton(
            "🌐 Archive.org Page", url=result["watch_url"]
        )])

        await q.message.reply_text(
            f"📥 *{title}* — Quality chunke download karo:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(btns),
        )

    elif source == "wikimedia":
        direct = result.get("direct_url", "")
        if direct:
            await q.message.reply_text(
                f"📥 *{title}* — Direct Download:",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("📥 Download", url=direct)
                ]]),
            )
        else:
            await q.message.reply_text("⚠️ Download link nahi mila.")

    else:
        # Fallback — give search page
        search_url = result.get("search_url") or result.get("watch_url", "")
        await q.message.reply_text(
            f"🔍 *{title}* ke liye Archive.org pe search karo:\n\n{search_url}\n\n"
            "_Wahan se apni pasand ki file download karo._",
            parse_mode="Markdown",
        )


# ══════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════

def main() -> None:
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, search))
    app.add_handler(CallbackQueryHandler(handle_download, pattern=r"^download_\d+$"))

    print("✅ Movie Bot chal raha hai — Watch aur Download dono free!")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
