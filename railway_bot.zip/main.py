
from bot.bot import *

if __name__ == "__main__":
    print("Starting bot...")
